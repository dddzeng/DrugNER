# Drug Named Entity Recognition (NER)

This project is a part of Advanced Human Language Technologies (AHLT) subject from 
Escola Tècnica Superior d'Enginyeria de Telecomunicacions de Barcelona (ETSETB), 
Universitat Politècnica de Catalunya (UPC).

